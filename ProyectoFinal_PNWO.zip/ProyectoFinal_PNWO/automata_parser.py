
import json


def parse_automata_json(texto):
    """
    Lee un autómata en formato JSON.
    Valida campos mínimos dependiendo del tipo.
    """
    try:
        data = json.loads(texto)
    except Exception as e:
        raise ValueError(f"Error al leer JSON: {e}")

    if not isinstance(data, dict):
        raise ValueError("El JSON debe representar un objeto/diccionario.")

    tipo = data.get("tipo", "").upper()
    TIPOS_VALIDOS = ["AFD", "AP", "PDA", "MT"]

    if tipo not in TIPOS_VALIDOS:
        raise ValueError(f"Tipo '{tipo}' no reconocido. Usa uno de: {TIPOS_VALIDOS}")

    # Campos mínimos comunes
    obligatorios = ["estados", "inicial", "aceptacion", "transiciones"]
    for campo in obligatorios:
        if campo not in data:
            raise ValueError(f"Falta el campo obligatorio '{campo}' en el JSON.")

    if not isinstance(data["estados"], list):
        raise ValueError("El campo 'estados' debe ser una lista.")

    if not isinstance(data["transiciones"], list):
        raise ValueError("El campo 'transiciones' debe ser una lista.")

    # AFD requiere alfabeto
    if tipo == "AFD" and "alfabeto" not in data:
        raise ValueError("Un AFD debe contener el campo 'alfabeto'.")

    return data


def parse_automata_text(texto):
    """
    Formato soportado:

    TIPO: AFD
    ESTADOS: q0, q1, q2
    ALFABETO: a, b
    INICIAL: q0
    ACEPTACION: q2
    TRANSICIONES:
    q0, a -> q1
    q1, b -> q2

    Soporta AFD, AP/PDA y MT.
    """
    lineas = [l.strip() for l in texto.splitlines() if l.strip() and not l.startswith("#")]
    automata = {"transiciones": []}

    for linea in lineas:

        # Campos clave: valor
        if ":" in linea:
            clave, valor = linea.split(":", 1)
            clave = clave.strip().upper()
            valor = valor.strip()

            if clave == "TIPO":
                automata["tipo"] = valor.upper()

            elif clave == "ESTADOS":
                automata["estados"] = [v.strip() for v in valor.split(",")]

            elif clave == "ALFABETO":
                automata["alfabeto"] = [v.strip() for v in valor.split(",")]

            elif clave == "INICIAL":
                automata["inicial"] = valor

            elif clave == "ACEPTACION":
                automata["aceptacion"] = [v.strip() for v in valor.split(",")]

        # Transición
        elif "->" in linea:
            izquierda, derecha = linea.split("->", 1)

            partes_izq = [p.strip() for p in izquierda.split(",")]
            partes_der = [p.strip() for p in derecha.split(",")]

            trans = {}

            # AFD: q,a->q
            # PDA: q,a,Z -> q,Z
            # MT: q,a -> q,b,D
            trans["desde"] = partes_izq[0]

            if len(partes_izq) >= 2:
                trans["entrada"] = partes_izq[1]

            if len(partes_izq) >= 3:
                trans["pila_pop"] = partes_izq[2]

            trans["hacia"] = partes_der[0]

            if len(partes_der) >= 2:
                # Para PDA = push
                # Para MT  = símbolo nuevo
                trans["extra"] = partes_der[1]

            if len(partes_der) >= 3:
                # Para MT: dirección L/R
                trans["dir"] = partes_der[2]

            automata["transiciones"].append(trans)


   
    if "tipo" not in automata:
        raise ValueError("Falta el campo TIPO en el autómata de texto.")

    tipo = automata["tipo"]

    if tipo not in ["AFD", "AP", "PDA", "MT"]:
        raise ValueError("Tipo de autómata no reconocido. Usa AFD, AP/PDA o MT.")

    obligatorios = ["estados", "inicial", "aceptacion", "transiciones"]
    for campo in obligatorios:
        if campo not in automata:
            raise ValueError(f"Falta el campo '{campo}' en el autómata de texto.")

    # AFD requiere alfabeto
    if tipo == "AFD" and "alfabeto" not in automata:
        raise ValueError("Un AFD debe tener ALFABETO definido.")

    return automata
