
from flask import Flask, render_template, request, jsonify, make_response, send_file
from graphviz import Digraph

from gramatica import Gramatica
from generador_ejemplos import GeneradorEjemplos
from visualizador import VisualizadorAutomata
from automata_parser import parse_automata_json, parse_automata_text
from automata_clasificador import clasificar_por_automata
from converters import regex_a_afd, afd_a_gramatica_regular
from tutor_chomsky import generar_pregunta, evaluar_respuesta_tipo

from io import BytesIO
import os

app = Flask(__name__, template_folder="templates")


# Página principal

@app.route("/")
def inicio():
    return render_template("index.html")

# Clasificación de gramáticas

@app.route("/api/clasificar", methods=["POST"])
def clasificar():
    datos = request.json
    gr_texto = datos.get("gramatica", "")
    try:
        g = Gramatica(gr_texto)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({
        "tipo": g.tipo,
        "pasos": g.pasos,
        "no_terminales": g.no_terminales(),
        "terminales": g.terminales(),
        "producciones": [repr(p) for p in g.producciones],
        "inicial": g.simbolo_inicial
    })


# Generar ejemplos de gramática

@app.route("/api/ejemplos", methods=["POST"])
def ejemplos():
    datos = request.json
    try:
        g = Gramatica(datos.get("gramatica", ""))
        generador = GeneradorEjemplos(g)
        ejemplos = generador.generar()
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({"ejemplos": ejemplos})

# Visualizar gramática/automata

@app.route("/api/visualizar", methods=["POST"])
def visualizar():
    datos = request.json
    try:
        g = Gramatica(datos.get("gramatica", ""))
        dot = VisualizadorAutomata(g).construir_dot()
        svg = dot.pipe().decode("utf-8")
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    return make_response(svg, 200, {'Content-Type': 'image/svg+xml'})


# Analizar autómata

@app.route("/api/analizar_automata", methods=["POST"])
def analizar_automata():
    datos = request.json
    texto = datos.get("automata", "")
    try:
        try:
            aobj = parse_automata_json(texto)
        except Exception:
            aobj = parse_automata_text(texto)
        nivel, mensaje = clasificar_por_automata(aobj)
    except Exception as e:
        return jsonify({"error": "No se pudo parsear autómata: " + str(e)}), 400

    return jsonify({"nivel": nivel, "mensaje": mensaje, "automata": aobj})


# Conversor regex -> AFD -> gramática regular

@app.route("/api/converter/regex_to_all", methods=["POST"])
def regex_to_all():
    datos = request.json
    regex = datos.get("regex", "")
    try:
        afd = regex_a_afd(regex)
        gr_text = afd_a_gramatica_regular(afd)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return jsonify({"afd": afd, "gramatica_regular": gr_text})


# Tutor (pregunta/quiz)

@app.route("/api/tutor/pregunta", methods=["GET"])
def tutor_pregunta():
    try:
        p = generar_pregunta()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify(p)

@app.route("/api/tutor/evaluar", methods=["POST"])
def tutor_evaluar():
    datos = request.json
    entrada = datos.get("entrada", "")
    respuesta = datos.get("respuesta", "")
    try:
        ok, expl = evaluar_respuesta_tipo(entrada, respuesta)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({"correcto": ok, "explicacion": expl})


# Endpoint de prueba: Gramáticas tipo 0 y tipo 1

@app.route("/api/ejemplo_tipo", methods=["GET"])
def ejemplo_tipo():
    tipo = request.args.get("tipo", "0")
    if tipo == "0":
        gr_texto = """
AB -> BA
A -> a
B -> b
"""
    elif tipo == "1":
        gr_texto = """
S -> aSB | ab
B -> b
"""
    else:
        return jsonify({"error": "Tipo desconocido"}), 400

    try:
        g = Gramatica(gr_texto)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({
        "gramatica": gr_texto.strip(),
        "tipo": g.tipo,
        "pasos": g.pasos,
        "no_terminales": g.no_terminales(),
        "terminales": g.terminales(),
        "producciones": [repr(p) for p in g.producciones],
        "inicial": g.simbolo_inicial
    })


# Generación de reportes PDF

@app.route("/api/reporte_pdf", methods=["POST"])
def reporte_pdf():
    datos = request.json
    gr_texto = datos.get("gramatica", "")

    try:
        g = Gramatica(gr_texto)
    except Exception as e:
        return jsonify({"error": f"No se pudo generar la gramática: {str(e)}"}), 400

    try:
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.utils import ImageReader
        from io import BytesIO

        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=letter)
        width, height = letter
        y = height - 50

        # Título
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y, "Reporte de Gramática / Autómata")
        y -= 30

        # Gramática
        c.setFont("Helvetica", 12)
        for linea in gr_texto.strip().split("\n"):
            c.drawString(50, y, linea)
            y -= 15
            if y < 50:
                c.showPage()
                y = height - 50

        # Clasificación
        c.drawString(50, y, f"Tipo: {g.tipo}")
        y -= 20

        # Explicación paso a paso
        c.setFont("Helvetica", 10)
        for paso in g.pasos:
            for sublinea in paso.split("\n"):
                c.drawString(50, y, sublinea)
                y -= 12
                if y < 50:
                    c.showPage()
                    y = height - 50

        # Diagrama SVG -> PNG si disponible
        try:
            dot = VisualizadorAutomata(g).construir_dot()
            svg_bytes = dot.pipe()
            try:
                import cairosvg
                png_bytes = cairosvg.svg2png(bytestring=svg_bytes)
                image = ImageReader(BytesIO(png_bytes))
                c.showPage()
                c.drawImage(image, 50, 250, width=500, preserveAspectRatio=True)
            except Exception:
                pass
        except Exception:
            pass

        c.save()
        buffer.seek(0)

        # Guardar PDF local (opcional)
        os.makedirs("reportes", exist_ok=True)
        with open(os.path.join("reportes", "reporte.pdf"), "wb") as f:
            f.write(buffer.getvalue())

        # Enviar PDF para descargar
        return send_file(buffer, as_attachment=True, download_name="reporte.pdf", mimetype="application/pdf")

    except ModuleNotFoundError:
        return jsonify({"error": "No se pudo generar PDF: reportlab no está instalado."}), 500
    except Exception as e:
        return jsonify({"error": f"No se pudo generar PDF: {str(e)}"}), 500


def comparar_gramaticas_heuristica(gr_texto1, gr_texto2, max_cadenas=20, max_pasos=10):
    try:
        g1 = Gramatica(gr_texto1)
        g2 = Gramatica(gr_texto2)
    except Exception as e:
        return {"error": f"No se pudieron analizar las gramáticas: {e}"}

    gen1 = GeneradorEjemplos(g1, max_pasos=max_pasos)
    gen2 = GeneradorEjemplos(g2, max_pasos=max_pasos)

    ejemplos1 = set(gen1.generar(cantidad=max_cadenas))
    ejemplos2 = set(gen2.generar(cantidad=max_cadenas))

    comunes = ejemplos1 & ejemplos2

    if not comunes:
        eq = "No parece equivalente"
    elif len(comunes) >= min(len(ejemplos1), len(ejemplos2)) // 2:
        eq = "Posible equivalencia (muchas cadenas coinciden)"
    else:
        eq = "Inconcluso, poca coincidencia"

    return {
        "gramatica1_ejemplos": list(ejemplos1),
        "gramatica2_ejemplos": list(ejemplos2),
        "comunes": list(comunes),
        "resultado": eq
    }


@app.route("/api/comparar_gramaticas", methods=["POST"])
def comparar_gramaticas_api():
    datos = request.json
    gr1 = datos.get("gramatica1", "")
    gr2 = datos.get("gramatica2", "")
    max_cadenas = datos.get("max_cadenas", 20)
    max_pasos = datos.get("max_pasos", 10)

    if not gr1 or not gr2:
        return jsonify({"error": "Debe ingresar ambas gramáticas"}), 400

    resultado = comparar_gramaticas_heuristica(gr1, gr2, max_cadenas, max_pasos)
    return jsonify(resultado)

def visualizar_afd(afd_json):
    dot = Digraph(format="svg")
    dot.attr(rankdir="LR")

    # Crear nodos
    for estado in afd_json["estados"]:
        shape = "doublecircle" if estado in afd_json.get("aceptacion", []) else "circle"
        dot.node(estado, shape=shape)

    # Crear transiciones
    for t in afd_json.get("transiciones", []):
        desde = t["desde"]
        hacia = t["hacia"]
        entrada = t["entrada"]
        dot.edge(desde, hacia, label=entrada)

    return dot.pipe().decode("utf-8")


#Endpoint para visualizar autómata
@app.route("/api/visualizar_automata", methods=["POST"])
def api_visualizar_automata():
    data = request.get_json()
    try:
        svg = visualizar_afd(data["automata"])
        return svg  
    except Exception as e:
        return jsonify({"error": str(e)}), 400



# Ejecutar aplicación
if __name__ == "__main__":
    app.run(debug=True, port=5000)