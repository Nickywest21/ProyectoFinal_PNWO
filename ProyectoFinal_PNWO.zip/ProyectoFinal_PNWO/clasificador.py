
class ClasificadorChomsky:
    def __init__(self, gramatica):
        self.G = gramatica

    def clasificar(self):
        try:
            return self.G.clasificar()
        except Exception as e:
            return "Error", [f"No se pudo clasificar: {e}"]
