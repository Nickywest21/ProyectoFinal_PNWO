

def clasificar_por_automata(automata_obj):

    if "transiciones" not in automata_obj:
        return ("Inválido", "No existe el campo 'transiciones' en el autómata.")

    tipo_declarado = automata_obj.get("tipo", "").strip().upper()
    trans = automata_obj.get("transiciones", [])


    # Mapa directo de tipos declarados
 

    tabla_tipos = {
        # REGULARES
        "AFD": ("Tipo 3 (Regular)", "Autómata finito determinista (AFD)."),
        "DFA": ("Tipo 3 (Regular)", "Autómata finito determinista (DFA)."),
        "NFA": ("Tipo 3 (Regular)", "Autómata finito no determinista (NFA)."),

        # LIBRES DE CONTEXTO
        "AP":  ("Tipo 2 (Libre de contexto)", "Autómata con pila (AP)."),
        "PDA": ("Tipo 2 (Libre de contexto)", "Autómata con pila (PDA)."),

        # SENSIBLES AL CONTEXTO
        "LBA": ("Tipo 1 (Sensible al contexto)", "Autómata lineal acotado (LBA)."),
        "LINEAR_BOUNDED_AUTOMATON": ("Tipo 1 (Sensible al contexto)", "Autómata lineal acotado (LBA)."),

        # TIPO 0
        "MT": ("Tipo 0 (No restringida)", "Máquina de Turing."),
        "TM": ("Tipo 0 (No restringida)", "Máquina de Turing."),
        "TURING": ("Tipo 0 (No restringida)", "Máquina de Turing."),
        "MÁQUINA DE TURING": ("Tipo 0 (No restringida)", "Máquina de Turing.")
    }

    if tipo_declarado in tabla_tipos:
        return tabla_tipos[tipo_declarado]

 
    # Detección de PDA por pila
    def usa_pila(t):
        """Detecta si una transición manipula pila aunque no use nombres estándar."""
        keys = [k.lower() for k in t.keys()]
        if "pila" in "".join(keys):
            return True
        # nombres alternativos
        pila_pop = (t.get("pila_pop") or "").lower()
        pila_push = (t.get("pila_push") or "").lower()
        if pila_pop or pila_push:
            return True
        # llaves no estándar que contengan 'stack'
        if "stack" in "".join(keys):
            return True
        return False

    if any(usa_pila(t) for t in trans):
        return ("Tipo 2 (Libre de contexto)",
                "Detección automática: Se detectó manipulación de pila → PDA (Tipo 2).")


    #  Detección de Máquina de Turing incompleta
    def parece_turing(t):
        """Detecta señales de una transición tipo Turing."""
        return any(k in t for k in ("escribir", "mover", "dir", "write", "move"))

    if any(parece_turing(t) for t in trans):
        return ("Tipo 0 (No restringida)",
                "Se detectaron acciones de cinta (escribir/mover) → Máquina de Turing.")


    #  Detección de AFD vs AFN (determinismo)
    trans_map = {}  # (estado, entrada) → lista de destinos
    for t in trans:
        estado = t.get("desde")
        entrada = t.get("entrada", "")
        destino = t.get("hacia")

        if estado is None or destino is None:
            continue

        clave = (estado, entrada)
        trans_map.setdefault(clave, []).append(destino)

    # ¿Alguna transición tiene múltiples destinos? → AFN
    if any(len(destinos) > 1 for destinos in trans_map.values()):
        return ("Tipo 3 (Regular)", "El autómata es NO determinista → AFN (Tipo 3).")


    #  Si nada indicó lo contrario → AFD
    return ("Tipo 3 (Regular)",
            "Se detectó un autómata sin pila, sin operaciones de cinta y determinista → AFD (Tipo 3).")
