
try:
    from automata.fa.dfa import DFA
    from automata.regex.regular_expression import RegularExpression
    HAS_AUTOMATA_LIB = True
except ImportError:
    HAS_AUTOMATA_LIB = False


from produccion import Produccion



def regex_a_afd(regex):


    if not isinstance(regex, str) or regex.strip() == "":
        raise ValueError("La expresión regular no puede estar vacía.")


    if HAS_AUTOMATA_LIB:
        try:
            re_obj = RegularExpression(regex)
            nfa = re_obj.to_epsilon_nfa()
            dfa = DFA.from_nfa(nfa)

        except Exception as e:
            raise ValueError(f"Error procesando la expresión regular: {e}")

        return {
            "tipo": "AFD",
            "estados": sorted(dfa.states),
            "alfabeto": sorted(dfa.input_symbols),
            "inicial": dfa.initial_state,
            "aceptacion": sorted(dfa.final_states),
            "transiciones": [
                {"desde": s, "entrada": sym, "hacia": d}
                for s, row in dfa.transitions.items()
                for sym, d in row.items()
            ]
        }

    if regex.strip() == "(a|b)*abb":
        return {
            "tipo": "AFD",
            "estados": ["q0", "q1", "q2", "q3"],
            "alfabeto": ["a", "b"],
            "inicial": "q0",
            "aceptacion": ["q3"],
            "transiciones": [
                {"desde": "q0", "entrada": "a", "hacia": "q1"},
                {"desde": "q0", "entrada": "b", "hacia": "q0"},
                {"desde": "q1", "entrada": "a", "hacia": "q1"},
                {"desde": "q1", "entrada": "b", "hacia": "q2"},
                {"desde": "q2", "entrada": "a", "hacia": "q1"},
                {"desde": "q2", "entrada": "b", "hacia": "q3"},
                {"desde": "q3", "entrada": "a", "hacia": "q1"},
                {"desde": "q3", "entrada": "b", "hacia": "q0"},
            ]
        }

    # Si no se tiene fallback:
    raise NotImplementedError(
        "La librería automata-lib no está instalada y no hay fallback disponible para este regex."
    )


def afd_a_gramatica_regular(afd):
    """
    Convierte un AFD a una gramática regular (tipo 3).

    Retorna un string con las producciones, ej:

        q0 -> a q1 | b
        q1 -> b

    Regla especial:
        Si un estado es final, debe tener producción ε.
    """

    # Validación de diccionario
    if not isinstance(afd, dict):
        raise ValueError("El AFD debe ser un diccionario.")

    estados = afd.get("estados")
    transiciones = afd.get("transiciones")
    aceptacion = afd.get("aceptacion")
    inicial = afd.get("inicial")

    if not estados or not transiciones or inicial is None or aceptacion is None:
        raise ValueError(
            "El AFD debe contener: estados, transiciones, inicial y aceptacion."
        )

    producciones = []

    # Procesar cada estado
    for estado in estados:
        reglas = []

        # Si es estado final → producción ε
        if estado in aceptacion:
            reglas.append("ε")

        # Transiciones desde este estado
        for t in transiciones:
            if t.get("desde") == estado:
                s = t.get("entrada")
                dest = t.get("hacia")

                # Si el destino es final → regla terminal
                if dest in aceptacion:
                    reglas.append(s)

                # Regla regular: aB
                reglas.append(f"{s}{dest}")

        # Crear la producción si hay reglas
        if reglas:
            producciones.append(Produccion(estado, reglas))

    # Convertimos a string legible
    return "\n".join(repr(p) for p in producciones)
