import re
from produccion import Produccion

class Gramatica:
    def __init__(self, texto):
        self.producciones = []
        self.simbolo_inicial = None
        self._analizar_texto(texto)
        self.tipo, self.pasos = self.clasificar()

    def _analizar_texto(self, texto):
        if not texto.strip():
            raise ValueError("Gramática vacía")
        lineas = [l.strip() for l in texto.split("\n") if l.strip()]
        patron = re.compile(r"^(?P<izq>[A-Z][A-Za-z0-9]*)\s*(?:->|→)\s*(?P<der>.+)$")
        for i, linea in enumerate(lineas):
            m = patron.match(linea)
            if not m:
                raise ValueError(f"Línea inválida: {linea}")
            izq = m.group("izq")
            der = m.group("der").strip()
            alternantes = [x.strip() for x in der.split("|")]
            self.producciones.append(Produccion(izq, alternantes))
        self.simbolo_inicial = self.producciones[0].lado_izquierdo

    def no_terminales(self):
        return sorted({p.lado_izquierdo for p in self.producciones})

    def terminales(self):
        ts = set()
        for p in self.producciones:
            for der in p.lados_derechos:
                for c in der:
                    if c.islower():
                        ts.add(c)
        return sorted(ts)

    def clasificar(self):
        pasos = []
        es_tipo3 = True

        for p in self.producciones:
            A = p.lado_izquierdo
            for alpha in p.lados_derechos:
                # Tipo 3 derecha: aB o solo terminal
                if re.fullmatch(r"[a-z][A-Z]?", alpha) or re.fullmatch(r"[a-z]", alpha):
                    if len(alpha) == 1:
                        pasos.append(f"{A} -> {alpha} terminal único, regular")
                    else:
                        pasos.append(f"{A} -> {alpha} regular derecha")
                # Tipo 3 izquierda: Ba (no implementaremos para entregar rápido)
                else:
                    pasos.append(f"{A} -> {alpha} NO es regular")
                    es_tipo3 = False

        if es_tipo3:
            pasos.append("\nGramática Tipo 3 (Regular derecha)")
            return "Tipo 3 (Regular derecha)", pasos
        else:
            pasos.append("\nGramática Tipo 2 (Libre de contexto)")
            return "Tipo 2 (Libre de contexto)", pasos
