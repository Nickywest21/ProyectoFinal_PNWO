import random


class GeneradorEjemplos:


    EPSILONS = {"ε", "epsilon", "eps", "lambda", "λ", ""}

    def __init__(self, gramatica, max_pasos=10):
        self.G = gramatica
        self.max_pasos = max_pasos
        self.no_terminales = set(gramatica.no_terminales())


    def _derivacion_aleatoria(self):
        actual = [self.G.simbolo_inicial]

        for _ in range(self.max_pasos):

            # Elegir un no terminal al azar (no siempre el primero)
            indices_nt = [i for i, t in enumerate(actual) if t in self.no_terminales]
            if not indices_nt:
                break

            indice_nt = random.choice(indices_nt)
            nt = actual[indice_nt]

            # Todas las producciones de ese NT
            prods = [p for p in self.G.producciones if p.lado_izquierdo == nt]
            if not prods:
                return None

            prod = random.choice(prods)
            alt = random.choice(prod.lados_derechos)

            # Epsilon
            if alt in self.EPSILONS:
                reemplazo = []
            else:
                # Tokenización segura (1 char = 1 símbolo en tu diseño)
                reemplazo = list(alt)

            # Reemplazar
            actual = actual[:indice_nt] + reemplazo + actual[indice_nt + 1:]

        # Si quedó algún no terminal, derivación inconclusa
        if any(t in self.no_terminales for t in actual):
            return None

        return "".join(actual) if actual else "ε"


    def generar(self, cantidad=5):
        resultados = set()
        intentos = cantidad * 10  # mayor probabilidad

        for _ in range(intentos):
            s = self._derivacion_aleatoria()
            if s:
                resultados.add(s)
            if len(resultados) >= cantidad:
                break

        # Si no se pudo generar nada:
        if not resultados:
            return ["(No fue posible generar cadenas)"]

        return sorted(resultados)
