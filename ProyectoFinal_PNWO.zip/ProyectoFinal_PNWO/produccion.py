class Produccion:
    def __init__(self, izq, derechos):
        self.lado_izquierdo = izq.strip()
        self.lados_derechos = [d.strip() for d in derechos]

    def __repr__(self):
        return f"{self.lado_izquierdo} -> {' | '.join(self.lados_derechos)}"
