from graphviz import Digraph


class VisualizadorAutomata:


    EPSILONS = {"ε", "epsilon", "eps", "lambda", "λ", ""}

    def __init__(self, obj):

        self.obj = obj
        # Detectar si es gramática o autómata
        if hasattr(obj, "producciones"):
            self.tipo = "gramatica"
            self.G = obj
            self.no_terminales = set(obj.no_terminales())
            self._validar_regularidad()
        elif all(hasattr(obj, attr) for attr in ("estados", "inicial", "aceptacion", "transiciones")):
            self.tipo = "automata"
        else:
            raise ValueError("Objeto no válido para visualización")

 
    def _validar_regularidad(self):
        S = self.G.simbolo_inicial

        for p in self.G.producciones:
            A = p.lado_izquierdo

            # Lado izquierdo debe ser un solo símbolo no terminal
            if len(A) != 1 or A not in self.no_terminales:
                raise ValueError(
                    f"Producción inválida en gramática regular: "
                    f"{A} -> {' | '.join(p.lados_derechos)} "
                    "(El lado izquierdo debe ser UN no terminal)"
                )

            for alt in p.lados_derechos:

                # EPSILON
                if alt in self.EPSILONS:
                    if A != S:
                        raise ValueError(
                            f"Epsilon solo permitido para el símbolo inicial.\n"
                            f"Producción inválida: {A} -> {alt!r}"
                        )
                    continue

                tokens = list(alt)

                if len(tokens) == 1:
                    # Terminal: A → a
                    if tokens[0] in self.no_terminales:
                        raise ValueError(
                            f"Regla inválida: {A} → {alt}. "
                            f"Una producción A → B NO es regular."
                        )

                elif len(tokens) == 2:
                    t0, t1 = tokens

                    # Solo permitido: aB
                    if t0 in self.no_terminales or t1 not in self.no_terminales:
                        raise ValueError(
                            f"Regla inválida: {A} → {alt}. "
                            f"La única forma válida de longitud 2 es aB."
                        )
                else:
                    raise ValueError(
                        f"Regla inválida: {A} → {alt}. "
                        f"Las gramáticas regulares solo permiten 1 o 2 símbolos."
                    )

  
    # Construcción del autómata (NFA)
   
    def construir_dot(self):
        dot = Digraph(format="svg")
        dot.attr(rankdir="LR")

        if self.tipo == "gramatica":
            # misma lógica que ya tienes
            for nt in self.no_terminales:
                dot.node(nt, shape="circle")
            dot.node("ACEPTA", shape="doublecircle")
            S = self.G.simbolo_inicial
            for p in self.G.producciones:
                A = p.lado_izquierdo
                for alt in p.lados_derechos:
                    if alt in self.EPSILONS:
                        dot.edge(A, "ACEPTA", label="ε")
                        continue
                    tokens = list(alt)
                    if len(tokens) == 1:
                        dot.edge(A, "ACEPTA", label=tokens[0])
                    elif len(tokens) == 2:
                        a, B = tokens
                        dot.edge(A, B, label=a)
        else:
            # entrada = autómata
            for q in self.obj.estados:
                shape = "doublecircle" if q in self.obj.aceptacion else "circle"
                dot.node(q, shape=shape)
            for t in self.obj.transiciones:
                dot.edge(t["desde"], t["hacia"], label=t["entrada"])

        return dot


