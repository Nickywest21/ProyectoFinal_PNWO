import random
from gramatica import Gramatica

SAMPLES_GRAMATICA = {
    "tipo3": "S -> aA | b\nA -> aS | a",
    "tipo2": "S -> aSb | ab",
    "tipo1": "S -> aSB | ab\nB -> b",
    "tipo0": "S -> AB | a\nA -> aS\nB -> b"
}

def generar_pregunta():
    t = random.choice(list(SAMPLES_GRAMATICA.keys()))
    gram = SAMPLES_GRAMATICA[t]
    return {"pregunta": f"Clasifica la siguiente gramática:\n{gram}", "solucion": t}

def evaluar_respuesta_tipo(entrada, respuesta_usuario):
    g = Gramatica(entrada)
    tipo, pasos = g.clasificar()
    correcto = respuesta_usuario.strip().lower() in tipo.lower()
    expl = "\n".join(pasos)
    return correcto, expl
